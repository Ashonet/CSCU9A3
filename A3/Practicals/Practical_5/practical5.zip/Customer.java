/**
 * Representation of a shop customer.
 *
 * @author cma
 * @date 11/2011
 *
 */
public class Customer {

	// For this we don't really care what attributes a customer might have, hence
	// the customer class is empty. In a "real" system this wouldn't be the case...

}
