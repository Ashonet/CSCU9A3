import static org.junit.Assert.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class ConverterTest
{
	private static final double ACCURACY = 0.05;

	private static Converter converter;

	@BeforeAll
	public static void setup()
	{
		// This method only setups the unit testing.
		// In other words, this method is responsible for instantiating or initializing 
		// any variables that unit test methods need.
		// There are different annotations as can be seen here
		// https://junit.org/junit5/docs/current/user-guide/
		// https://junit.org/junit5/docs/current/api/org.junit.jupiter.api/org/junit/jupiter/api/package-summary.html
		converter = new Converter();		
	}

	@Test
	public void test_mph2kph()
	{
		// Test convert mph to kph -- comparing doubles using assertEquals
		assertEquals("mph2kmh failed:", 38.6243, converter.mph2kph(24), ACCURACY);
		assertEquals("mph2kmh failed:", 96.5606, converter.mph2kph(60), ACCURACY);
	}
	
	@Test
	public void test_mph2kmh_printing()
	{
		// Test convert_array -- comparing Strings using assertEquals
		assertEquals("mph2kmh_printing failed:", "60.0 mph = 96.5 kph", converter.mph2kph_printing(60));
	}
	
}
